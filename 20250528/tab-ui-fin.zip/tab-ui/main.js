import { TabUI } from './TabUI.js';

new TabUI(
  ['세계의 날씨', '오늘의 메뉴', '모두연은?', 'AAA'],
  '.global-header',
  // 1
);

new TabUI(
  [111, 222, 333],
  'footer',
  2
);